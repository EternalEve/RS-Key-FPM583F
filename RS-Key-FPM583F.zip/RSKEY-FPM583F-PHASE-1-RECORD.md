<!-- SPDX-License-Identifier: AGPL-3.0-only -->
<!-- Copyright (C) 2026 RS-Key contributors -->

# 第一阶段执行记录

2026-10-11。状态：静态核对进行中；构建环境未就绪，尚未通过阶段验收。

## 当前设备与范围

用户在本次会话明确说明：当前目标为全空板，板内无必要数据。此说明替代
计划中“当前板有真实 passkey”的起始假设，不改写 SAFETY.md 的历史记录。
目标仍按工程计划采用 RP2350-Zero-CM、2MB Flash；本轮未连接设备，实物型号、
序列号、芯片修订版及 OTP 状态未验证。空板描述不作为 OTP 空白证据。

本轮只做本地文件及构建环境检查、源码静态审查和官方板级资料核对。
不包含烧录、运行目标固件、复位、擦除、签名或 OTP 操作。

## 1. 源码与依赖身份

实际 HEAD：`7c9a57836647c363a9f006da1892e886869afb61`，与计划基线一致。
初始工作树已有 `.gitignore` 修改和未跟踪的 FPM583F 规格书 PDF，均保留。
计划及本执行记录被现有 `/RSKEY-FPM583*` 规则忽略，需另行保存；不修改忽略规则。

文件字节 SHA256（Windows 检出文件，不代表 Linux 检出文件的字节哈希）：

| 文件 | SHA256 |
| --- | --- |
| Cargo.lock | `641aa0bda7d81a8eeea3eb242f4aba1e506e8ba435b14833e61e23a69e759201` |
| flake.lock | `1c49bc97f3cf8267c4437619a0dc0487b758e8d6d781dc3c62e0d67f0caf413c` |
| tools/emu/Cargo.lock | `3bb59a89033a5b37d245e8fd5ecb6954eae136fb42bdd0b7c967d24c793a6d54` |

根、模拟器和 fuzz 锁文件所列 Embassy 修订均为
`6c28443489ad5940ab8c1824c090b1f8a7233bf6`。根与模拟器均保留
`third_party/sequential-storage` 本地补丁，不替换成同版本上游库。
源码许可按仓库 AGPL-3.0-only；候选指纹驱动未引入，许可选择待协议确认后处理。

## 2. 环境核对与 Windows 路线

已检查当前 PATH 与用户默认安装目录：未找到 Nix、Rust/Cargo、flip-link、
ARM GCC、picotool，也未找到默认 `.cargo` / `.rustup` 目录。
Git for Windows 的 `bash.exe` 存在。该结果不声称整台机器没有其他目录的工具。

`wsl --list --verbose` 返回帮助并失败，未取得可用发行版；Docker 客户端存在，
但沙箱外重查仍不能连接 `dockerDesktopLinuxEngine`。未安装或启动系统组件。
用户随后询问 Windows 原生路线；暂不安装 WSL。

Windows 原生构建是待验证替代路线：

- 固定明确版本的 Rust，安装 `thumbv8m.main-none-eabihf`、rust-src、rustfmt、
  clippy、llvm-tools；同时准备所选 Windows host triple 的链接工具。
- 提供 Windows ARM GNU toolchain。`crates/rsk-rsa/build.rs` 明确调用
  `arm-none-eabi-gcc` 编译 Cortex-M33 C/汇编，不能仅安装 Rust。
- 提供 flip-link，并将该 Rust sysroot 中的 rust-lld 放入构建会话 PATH。
- 提供 picotool 与符号工具，用 Git Bash 执行现有分区后处理；验证 Windows
  路径传递和 ELF/UF2 输出，不跳过分区表。
- 模拟器还链接 SDL2。默认熵入口 `tools/emu/src/rng.rs:25` 使用
  `/dev/urandom`，Windows 原样正常启动不可用。第二阶段 2.1 明确要求“不以固定
  种子掩盖平台启动问题”；已有 `--seed` 仅用于明确的确定性测试，不能代替
  Windows 正常系统熵入口的适配与验收，禁止用于设备固件。
- Windows 原生检查不等价于仓库规定的 `nix develop -c ./scripts/check.sh`。
  原 gate 内还直接执行 `nix flake lock`，Git Bash 不能独自替代其 Nix 环境。
  完整 gate 需在可运行既有 Nix 配置的环境执行；这不是计划要求开发主机必须
  使用 Linux。第一阶段允许固定版本的 rustup 路线，并要求在该路线中完成真实
  重建和布局核对，不要求不同平台产物字节相同。不修改 gate 或工具链 pin 掩盖差异。

工具安装及 Windows 编译尚未执行，工具版本和可重现性均待真实结果。

## 3. 目标配置与静态布局

`nix/firmware.nix` 的 `firmware-2mb` 已明确设置 `flashSize="2M"`、
`kvmain="896K"`，不启用 display、no-touch、bench、always-uv 或 strict-up。
原始默认 USB 身份为 `1209:0001`；strict-config 是显式启用的可选 feature。
本轮未发现所检查的板级/测试/假密钥环境变量覆盖。

以下是由源码参数推算的 Flash 相对偏移，不是实际 ELF 测量：

| 区域 | 半开范围 | 容量 | 实际占用/余量 |
| --- | --- | --- | --- |
| 代码 | `0x000000..0x100000` | 1024KiB | 未测量 |
| 主 KV | `0x100000..0x1e0000` | 896KiB | 未测量 |
| 计数器 KV | `0x1e0000..0x200000` | 128KiB | 未测量 |
| 链接 RAM | `0x20000000..0x20080000` | 512KiB | 未测量 |

`firmware/build.rs` 同时生成 memory.x 并烘焙存储长度，flash_storage.rs 使用
相同配置。main.rs 预留 128KiB 堆供既有 RSA 路径使用；须在真实 ELF 静态段
计数中避免重复扣除。原 AGENTS/CONTRIBUTING 的笼统 no-alloc 描述与此已有例外
不完全一致，本轮不修改既有实现。

指纹增量分项：UART 缓冲/解析、模块操作状态、模板元数据及 pending 记录、
BioEnrollment 请求响应、任务/栈。全部尚无实测或可信大小估算；不预留完整
图像/模板上传缓冲，不依据注释中的镜像大小宣布资源足够。

官方 [CM 板资料](https://docs.waveshare.com/RP2350-Zero-CM)确认 RP2350A、
板载 2MB NOR Flash、WS2812、BOOT/RUN 按钮和两组 UART。
仓库没有 CM 专属 board TOML，不直接套用 waveshare-one 的 4MB 配置。
LED 引脚/顺序、UART TX/RX、TOUCHOUT、输入电气及供电负载分配尚待准确原理图核对。
LDO 标称能力不作为稳定供电实测结论。必要时离线诊断构建可显式 LED_KIND=none，
但它与原始默认镜像须分别记录，不能代替最终硬件配置。

## 4. 已核对的入口与副作用索引

| 位置 | 观察结果与后续约束 |
| --- | --- |
| .cargo/config.toml | runner 为 `picotool load -u -v -x -t elf`；目标固件不用 cargo run |
| nix/firmware.nix | Cargo offline/frozen 构建；pt.sh 后处理及 UF2 转换；所读 build/install phase 无设备加载、签名 |
| scripts/pt.sh | 从 ELF 符号读取 KV 边界，使用 picotool partition create 写主机输出文件 |
| scripts/check.sh | 含大量 profile/静态 gate 与临时构建；文件全量读取和完整执行尚待环境就绪；不能声称已审查每个间接脚本 |
| firmware/src/main.rs | USB attach 前扫描存储、迁移密封格式、ensure_seed、OpenPGP 初始化；条件性 at-rest lap；真实冷启动可推进 OTP applet 使用计数 |
| firmware/src/otp_keys.rs | 启动读取密钥并设置 page58 运行时 SW_LOCK；永久锁/rollback 写入为独立 apply 函数，并非启动处直接调用 |
| crates/rsk-device/src/ccid.rs | 默认构建有 Management 的 device-wide factory_wipe 路径，生物实现需统一协调 |
| crates/rsk-fido/src/reset.rs | CTAP Reset 窗口和显式 FID 集合；保留机构证明对象；指纹格式加入后须覆盖所有清理入口 |

OTP 永久写入函数的全部调用链、最终镜像启动元数据、Boot ROM 行为及所有
初始化入口尚未完成审查，不依据 Pico FIDO 的历史记录给 RS-Key 下相同结论。
裸 cargo ELF 未经 pt.sh 不带发布分区表；check.sh 最后留下 no-touch 测试镜像，
后续设备候选镜像必须独立重建并复核配置。

## 5. 模块能力与后续接入

本轮未打开规格书 PDF 核对页码，也未执行通用协议工具；下列结论只说明证据缺口：

| 能力 | 当前判定 | 最迟解决阶段 |
| --- | --- | --- |
| 电气/排线/启动、TOUCHOUT 新事件 | 资料及实物核对待完成 | 6，接线前 |
| 583F 对应固件帧格式、错误及忙状态 | 未确认；通用文本不能证明型号兼容 | 5 |
| 当前新鲜采样与可验证匹配槽号 | 未确认；没有绑定证据不能授予 UV | 5–6 |
| 采样反馈、最终保存、目录核对 | 未确认 | 5–6 |
| 删除/清库、写超时查询、取消收尾 | 未确认；保持未知结果隔离设计 | 5–6 |
| 模块身份、重复指纹反馈 | 未确认；不虚构能力 | 5 |

接入索引：rsk-sdk/src/presence.rs 的 UserPresence 当前将 builtin UV 定义为
屏幕 PIN；rsk-fido 的 clientpin/state/getinfo 和注册/断言处理是授权修改点。
rsk-device 提供组合与 presence 归属；firmware 的 worker/presence/ctap/IRQ
是执行桥接点；rsk-fs/rsk-store 提供共享耐久存储；tools/emu 的 device/presence/
rng/store 提供隔离注入点。尚未设计新契约或修改业务。

同步 worker 等待期间的 UART 缓冲推进、Flash/XIP 停顿、Keepalive/CANCEL
响应均待第三阶段模型及后续板上验证；不能等待同一执行器内无法运行的任务。
第二阶段沿用模拟器 TCP 通路与 python-fido2；标准客户端 transport 适配尚未核对。

## 6. 执行结果与剩余工作

| 检查 | 结果 |
| --- | --- |
| HEAD、初始 diff、三个锁文件哈希 | 已观察 |
| Embassy 根/emu/fuzz 修订、本地存储补丁 | 已静态核对 |
| Windows/WSL/Docker 工具可用性 | 已检查；环境未就绪 |
| 固件编译、分区打包、UF2 地址范围 | 未执行 |
| 主机单元测试、模拟器构建、完整 Nix gate | 未执行 |
| 真正重建与镜像哈希比较 | 未执行 |
| 实际代码、静态 RAM、栈及余量 | 未测量 |
| 实物型号、引脚、电气和协议行为 | 未验证 |

第一阶段尚未完成。Windows 原生替代路线尚未由用户选定，也未安装工具。
若采用该路线，下一步为固定工具版本、验证无屏 2MB 构建与主机检查，并完成
真实重建及资源测量；环境差异单独记录。第一阶段计划并未将 Linux/Nix 列为
唯一验收路线。仓库完整 gate 是独立的交付检查要求，不将替代检查当作 gate 通过。
